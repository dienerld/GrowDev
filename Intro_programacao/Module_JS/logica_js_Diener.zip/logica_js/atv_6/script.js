// 6. Escreva um algoritmo para ler uma temperatura em graus
// Fahrenheit, calcular e escrever o valor correspondente em graus
// Celsius.

const tempFahrenheit = 100;

const tempCelsius = (tempFahrenheit - 32) / 1.8;

console.log(tempCelsius.toFixed(2));
