const number = 20;

if (number % 2 === 0) {
  alert(`Número ${number} é par!`);
} else {
  alert(`Número ${number} é ímpar!`);
}
